#!/bin/bash

# Function to check if a URL redirects to another URL
check_redirect() {
    url=$1
    redirect_url=$(curl -s -L -o /dev/null -w '%{url_effective}' "$url")
    if [ "$url" != "$redirect_url" ]; then
        echo "The URL $url redirects to $redirect_url. It might be a clickbait."
    else
        echo "The URL $url does not redirect to another URL. It seems safe."
    fi
}

# Function to check for clickbait-like language in the webpage content
check_content() {
    url=$1
    content=$(lynx -dump -nolist "$url")
    clickbait_phrases=(
    "You won't believe" 
    "But first" 
    "Click here" 
    "This trick"
	"Install"
	"You'll be surprised"
    "You'll be floored"
    "You'll be blown away"
    "You'll be astounded"
    "Shocking truth"
    "Unbelievable"
    "Mind-blowing"
    "Can't even"
    "Wait until you see"
    "You must see"
    "This is insane"
    "Guess what happened"
    "Epic fail"
    "Won't last long"
    "Hurry before it's gone"
    "See it to believe it"
    "This will make you cry"
    "This will make you laugh"
    "This will make you scream"
    "You'll be shocked"
    "You'll be amazed"
    "You'll be stunned"
	"What happened next"
    "You'll never guess"
    "This is the secret"
    "They don't want you to know"
)


    for phrase in "${clickbait_phrases[@]}"; do
        if echo "$content" | grep -q "$phrase"; then
            echo "The URL $url contains the phrase '$phrase'. It might be a clickbait."
            return
        fi
    done

    echo "The URL $url does not contain common clickbait phrases. It seems safe."
}

# Test the functions with multiple URLs
urls=("http://example1.com" "http://example2.com" "http://example3.com")

for url in "${urls[@]}"; do
    check_redirect "$url"
    check_content "$url"
	
# Test the functions with a signle URL
#url="http://example.com"
#check_redirect "$url"
#check_content "$url"


The script uses curl and grep to detect potential clickbait by checking if a URL redirects to another URL. It also analyzes webpage content for common clickbait characteristics using lynx to extract text and grep to find common phrases. However, it may not work with JavaScript-heavy webpages. The script also identifies common clickbait phrases in headlines, but not all headlines with these phrases are necessarily clickbait. Also multiple url can be inserted 3 url can be use to enble fast scan of multiple website