#!/bin/bash

# Define the log files which been used inthe dir..
error_log="error.log"
access_log="access.log"

# Check if curl and jq are installed
if ! command -v curl &> /dev/null
then
    echo "curl could not be found, please install it."
    exit
fi

if ! command -v jq &> /dev/null
then
    echo "jq could not be found, please install it."
    exit
fi

# 1. The day with the max/most traffic on both log files
echo "Day with max traffic:"
awk '{print $4}' $access_log | cut -d: -f1 | uniq -c | sort -nr | head -1

# 2. Identifing the traffic from a particular user based on the time and number of access, indicating whether it is a user or a bot
echo "Traffic from each user:"
awk -F\" '{print $6}' $access_log | sort | uniq -c | sort -nr

# 3. Determine location, IP address and device used to access the site
echo "IP addresses, user agents, and locations:"
awk '{print $1,$12}' $access_log | sort | uniq -c | sort -nr | while read line; do
    ip=$(echo $line | awk '{print $2}')
    location=$(curl -s https://ipinfo.io/$ip | jq -r '.region, .country')
    echo "$line $location"
done
